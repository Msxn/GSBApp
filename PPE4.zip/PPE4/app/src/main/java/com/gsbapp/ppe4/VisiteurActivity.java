package com.gsbapp.ppe4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class VisiteurActivity extends AppCompatActivity {

    private TextView hello;
    private Button sendBtn, consultBtn, disconnectBtn;
    final SharedPreferences user = getSharedPreferences("user", Context.MODE_PRIVATE);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visiteurpage);


        sendBtn = findViewById(R.id.send);
        consultBtn = findViewById(R.id.consult);
        disconnectBtn = findViewById(R.id.disconnect);
        hello = findViewById(R.id.hello);

        final String login = user.getString("login", "NULL");

        hello.setText("Bonjour "+login+"!");

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String json = gotoUrl("http://mcol.myqnapcloud.com/PPE4/api.php?mode=saisie&user="+login);
                Log.d("Json", json);
            }
        });


        consultBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


        disconnectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(VisiteurActivity.this, LoginActivity.class);
                startActivity(i);
                finish();
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("onStop", "true");
    }

    public String gotoUrl(String url){ //lance une tache asynchrone pour aller chercher l'autorisation de connexion
        try {
            RequestByURL req = new RequestByURL();
            String result = req.execute(url).get();
            return result;
        }catch(Exception e){
            return "NULL";
        }
    }
}
