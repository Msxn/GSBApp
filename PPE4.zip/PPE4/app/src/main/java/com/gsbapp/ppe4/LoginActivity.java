package com.gsbapp.ppe4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private EditText login, mdp;
    private RadioButton visiteur, comptable;
    private Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide(); //hide the title bar

        login = findViewById(R.id.login);
        mdp = findViewById(R.id.mdp);
        visiteur = findViewById(R.id.visiteur);
        comptable = findViewById(R.id.comptable);
        submit = findViewById(R.id.submit);

        SharedPreferences user = getSharedPreferences("user", Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = user.edit();

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String logincontent = login.getText().toString();
                String mdpcontent = mdp.getText().toString();
                String type = "";
                if(visiteur.isChecked()){
                    type = "visiteur";
                }else if(comptable.isChecked()){
                    type = "comptable";
                }

                //si utilisateur connecté
                if(gotoUrl("http://mcol.myqnapcloud.com/PPE4/api.php?mode=login&login="+logincontent+"&mdp="+mdpcontent+"&type="+type)){
                    editor.putString("login", logincontent);
                    editor.putString("mdp", mdpcontent);
                    editor.apply();

                    Toast.makeText(LoginActivity.this, "Vous êtes bien identifié "+logincontent, Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(LoginActivity.this, VisiteurActivity.class);
                    startActivity(i);
                    finish();
                }else{
                    Toast.makeText(LoginActivity.this, "Identifiant incorrect", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    public boolean gotoUrl(String url){ //lance une tache asynchrone pour accéder à l'url et récupérer la réponse
        try {
            RequestByURL req = new RequestByURL();
            String result = req.execute(url).get();
            if(result.equals("match")){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            return false;
        }
    }
}
