<?php

$connect = mysqli_connect('localhost', 'root', 'mattdu02210boss2', 'test');


if($_GET['mode'] == 'login'){
    $type = ucfirst($_GET['type']);
    $q = 'SELECT login FROM '.$type.' WHERE login = "'.$_GET['login'].'" AND mdp = "'.$_GET['mdp'].'";';
    $r = mysqli_query($connect, $q);
    $fetch_r = mysqli_fetch_assoc($r);
    if(!is_null($fetch_r) && $fetch_r['login'] == $_GET['login']){
        echo "match";
    }else{
        echo "nomatch";
    }
}


elseif($_GET["mode"] == 'saisie'){
    $user = $_GET["user"];
    $q = 'SELECT * FROM LigneFraisForfait WHERE mois = "'.date("Y").date("m").'" AND idVisiteur = (SELECT id FROM Visiteur WHERE login = "'.$user.'")';
    //echo $q;
    $r = mysqli_query($connect, $q);
    while($temp = mysqli_fetch_assoc($r)){
        $key = $temp['idFraisForfait'];
        $fetch_r[$key] = $temp;
    }
    $jsonarray["forfait"] = $fetch_r;

    unset($fetch_r);

    $q = 'SELECT * FROM LigneFraisHorsForfait WHERE mois = "'.date("Y").date("m").'" AND idVisiteur = (SELECT id FROM Visiteur WHERE login = "'.$user.'")';
    //echo $q;
    $r = mysqli_query($connect, $q);
    for($i = 0; $temp = mysqli_fetch_assoc($r); $i++){
        $fetch_r[$i] = $temp;
    }
    $jsonarray["horsforfait"] = $fetch_r;

    echo json_encode($jsonarray);
}


mysqli_close($connect);